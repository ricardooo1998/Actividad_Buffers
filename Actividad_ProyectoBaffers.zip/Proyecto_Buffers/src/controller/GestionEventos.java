package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.AbstractButton;

import model.*;
import view.*;

public class GestionEventos {

	private GestionDatos model;
	private LaunchView view;
	private ActionListener actionListener_comparar, actionListener_buscar;

	public GestionEventos(GestionDatos model, LaunchView view) {
		this.model = model;
		this.view = view;
	}
	
	
	public void contol() {
		actionListener_comparar = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				try {
					call_compararContenido();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
		view.getComparar().addActionListener(actionListener_comparar);

		actionListener_buscar = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				call_buscarPalabra();
			}
		};
		view.getBuscar().addActionListener(actionListener_buscar);
	}

	private int call_compararContenido()  {
		boolean resultado;
		try {
			resultado = model.compararContenido(view.getFichero1().getText(), view.getFichero2().getText());
			 if (resultado==true)
		     {
				 view.getTextArea().setText("Los archivos son iguales");
		     }
		     else
		     {
		    	 view.getTextArea().setText("Los archivos no son iguales");
		     }
		} catch (Exception e) {
			e.printStackTrace();
		}
			return 1;
		}

	private void call_buscarPalabra() {
		int resultado;
		try 
		{
			resultado=model.buscarPalabra(view.getFichero1().getText(), view.getPalabra().getText(),view.getPrimera().isSelected());
			if (resultado!=-1)
			{
				if (view.getPrimera().isSelected())
				{
					view.getTextArea().setText("Se encontro la palabra: "+view.getPalabra().getText()+" por primera vez en la l�nea: "+resultado);
				}
				else
				{
					view.getTextArea().setText("Se encontro la palabra: "+view.getPalabra().getText()+" por ultima vez en la l�nea: "+resultado);
				}
			}
			else
			{
				view.getTextArea().setText("No se pudo encontrar ninguna palabra introducida");
			}
		}
		catch (IOException e)
		{
			view.showError("Error!");
		}
	}

}
