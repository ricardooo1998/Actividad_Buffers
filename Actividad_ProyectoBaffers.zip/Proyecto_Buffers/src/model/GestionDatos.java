package model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import view.LaunchView;

public class GestionDatos {

	public GestionDatos() {
		

	}

	//TODO: Implementa una funci�n para abrir ficheros
	
	//TODO: Implementa una funci�n para cerrar ficheros
	
	public boolean compararContenido (String fichero1, String fichero2) throws Exception
	{
		boolean iguales = true;
		FileReader fr1 = new FileReader("fichero1");
		FileReader fr2 = new FileReader("fichero2");
		 
		BufferedReader bf1 = new BufferedReader(fr1);
		BufferedReader bf2 = new BufferedReader(fr2);
		
		String Cad1 = bf1.readLine();
		String Cad2 = bf2.readLine();

		while ((Cad1!=null) || (Cad2!=null) && iguales) 
		{
			  if (Cad1==null || Cad2==null || !Cad1.equals(Cad2))
			  {
				  iguales = false;
				  Cad1 = bf1.readLine();
				  Cad2 = bf1.readLine();
			  }
		}
		return iguales;
	}

	public int buscarPalabra (String fichero1, String palabra, boolean primera_aparicion) throws IOException {
		int contador=0;
		int linea=0;
		int resultado=0;
		boolean palabraEncontrada=true;
		FileReader fr1 = new FileReader ("fichero1.txt");
		BufferedReader br1 = new BufferedReader(fr1);
		String cad=br1.readLine();
		
		if (primera_aparicion)
		{
			while ((cad!=null) && palabraEncontrada==false)
			{
				contador++;
				if (cad.compareTo(palabra)==0)
				{
					palabraEncontrada=true;
					linea=contador;
				}
				cad=br1.readLine();
			}
			if (linea==0)
			{
				resultado=-1;
			}
			else
			{
				resultado=linea;
			}
		}
		
		else
		{
			while ((cad!=null))
			{
				contador++;
				if (cad.compareTo(palabra)==0)
				{
					linea=contador;
				}
				cad=br1.readLine();
			}
			if (linea==0)
			{
				resultado=-1;
			}
			else
			{
				resultado=linea;
			}
		}
		fr1.close();
		br1.close();
		return resultado;
	}	

}
